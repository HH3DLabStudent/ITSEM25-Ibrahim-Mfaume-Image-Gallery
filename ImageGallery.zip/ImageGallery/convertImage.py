from PIL import Image

# List of images you want to convert
image_files = ["image1.png", "image2.png"]
output_names = ["image1", "image2"]

def convert_image(image_path, output_name):
    img = Image.open(image_path).convert("RGB")
    img = img.resize((200, 200))  # Resize to match your TFT layout

    pixels = list(img.getdata())

    with open(f"{output_name}.h", "w") as f:
        f.write(f"#ifndef {output_name.upper()}_H\n")
        f.write(f"#define {output_name.upper()}_H\n\n")
        f.write(f"#include <stdint.h>\n\n")
        f.write(f"const uint16_t {output_name}[] = {{\n")

        for i, pixel in enumerate(pixels):
            r, g, b = pixel
            # Convert to RGB565
            rgb565 = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)
            f.write(f"0x{rgb565:04X}, ")
            if (i + 1) % 10 == 0:
                f.write("\n")

        f.write("\n};\n\n")
        f.write(f"#endif // {output_name.upper()}_H\n")

    print(f"Converted {image_path} to {output_name}.h")

# Loop through the images
for path, name in zip(image_files, output_names):
    convert_image(path, name)
